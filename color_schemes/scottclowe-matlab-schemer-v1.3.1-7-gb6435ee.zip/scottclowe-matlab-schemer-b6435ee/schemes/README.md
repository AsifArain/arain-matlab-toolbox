MATLAB Schemes
==============

A collection of color schemes for MATLAB.

These color schemes can be enabled using the [MATLAB Schemer package].

[MATLAB Schemer package]: https://github.com/scottclowe/matlab-schemer
